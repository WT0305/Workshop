vti_encoding:SR|utf8-nl
vti_author:SR|LAPTOP-IGFR1B83\\JelexLKL
vti_modifiedby:SR|LAPTOP-IGFR1B83\\JelexLKL
vti_timelastmodified:TR|28 Sep 2023 12:38:07 -0000
vti_timecreated:TR|26 Sep 2023 07:42:34 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|tetris.html
vti_nexttolasttimemodified:TW|28 Sep 2023 12:29:39 -0000
vti_cacheddtm:TX|28 Sep 2023 12:38:07 -0000
vti_filesize:IR|20085
